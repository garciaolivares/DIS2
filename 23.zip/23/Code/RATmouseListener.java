/*RATmouselistener Interface 
 * Performance (when clicked)
 * */

public abstract interface RATmouseListener {
    public abstract void performance();   
}
