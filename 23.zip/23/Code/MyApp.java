public class MyApp {
	
	public static void main(String args[]){
		//create object WindowSystem to create and draw rectangle (desktop)
		WindowSystem desktop = new WindowSystem(800,600);
	}

}
